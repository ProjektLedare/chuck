from django.apps import AppConfig


class PrivateConfig(AppConfig):
    name = 'private'
